import PageLayout from "../components/layout/PageLayout";
import Header from "../components/layout/home3/Header";
import StickyHeader from "../components/layout/home3/StickyHeader";
import Footer from "../components/layout/home3/Footer";
import OfflineCourseDetailsContent from "../components/sections/course-details/OfflineCourseDetailsContent";

// Offline course detail page: /offline-courses/:slug  (FAQ = general FAQ, inside the content component)
const sections = [OfflineCourseDetailsContent];

const OfflineCourseDetails = () => (
  <PageLayout {...{ Header, StickyHeader, Footer, sections }} alwaysSticky />
);

export default OfflineCourseDetails;