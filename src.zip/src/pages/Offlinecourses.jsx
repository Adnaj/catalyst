import PageLayout from "../components/layout/PageLayout";
import Header from "../components/layout/home3/Header";
import StickyHeader from "../components/layout/home3/StickyHeader";
import Footer from "../components/layout/home3/Footer";
import OfflineCourseIntro from "../components/sections/courses/OfflineCourseIntro";
import OfflineCoursesAll from "../components/sections/courses/OfflineCoursesAll";
import Faq from "../components/sections/home3/Faq";
import Promo from "../components/sections/home3/Promo";

// Offline courses page. Uses the same layout as the online /courses page for now;
// swap any section below (or edit OfflineCourseIntro / OfflineCoursesAll) to redesign it.
const sections = [OfflineCourseIntro, Promo, OfflineCoursesAll,Faq];

const OfflineCourses = () => (
  <PageLayout {...{ Header, StickyHeader, Footer, sections }} alwaysSticky />
);

export default OfflineCourses;