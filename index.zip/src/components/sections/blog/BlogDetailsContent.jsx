import { Link, useParams } from "react-router-dom";
import ErrorContent from "../error/ErrorContent";
import {
  blogPosts,
  blogComments,
  blogTags,
  blogPath,
  getPost,
  categoryCounts,
  categoryPath,
  getRelatedPosts,
  defaultContent,
} from "../../../data/BlogPosts";

// Blog details page (route: /blog/:slug). Class names are the same as blog-details.html.
// Title, image, category, date and article content come from data/BlogPosts.js
// (post.content = list of blocks; a post without content shows `defaultContent`).

const pad = (n) => String(n).padStart(2, "0");
const countAll = (list) => list.reduce((n, c) => n + 1 + (c.replies?.length || 0), 0);

// One block of the article body: { type: "p" | "h3" | "list" | "quote", text | items }
const ContentBlock = ({ block }) => {
  switch (block.type) {
    case "h3":
      return <h3 className="tj-fade-anim">{block.text}</h3>;
    case "list":
      return (
        <ul className="tj_list tj-fade-anim">
          {block.items.map((t) => (
            <li key={t}>
              <i className="tji-check"></i>
              {t}
            </li>
          ))}
        </ul>
      );
    default:
      return <p className="tj-fade-anim">{block.text}</p>;
  }
};

const Comment = ({ c }) => (
  <li className="tj_wpost_comment">
    <div className="tj_wpost_comment_inner">
      <div className="tj_wpost_comment_thumb">
        <img src={c.avatar} alt={c.name} />
      </div>
      <div className="tj_wpost_comment_content">
        <div className="tj_wpost_comment_author">
          <h6 className="name">
            <a href="#" onClick={(e) => e.preventDefault()}>
              {c.name}
            </a>
          </h6>
          <span className="date">{c.date}</span>
        </div>
        <div className="tj_wpost_comment_text">
          <p>{c.text}</p>
        </div>
        <div className="tj_wpost_comment_reply">
          <a href="#" onClick={(e) => e.preventDefault()}>
            <i className="tji-reply"></i> Reply
          </a>
        </div>
      </div>
    </div>

  </li>
);

const BlogDetailsContent = () => {
  const { slug } = useParams();
  const post = getPost(slug);
  if (!post) return <ErrorContent />;

  const index = blogPosts.findIndex((p) => p.slug === slug);
  const prev = blogPosts[index - 1];
  const next = blogPosts[index + 1];
  const related = getRelatedPosts(slug, 3); // same category first
  const total = countAll(blogComments);
  const blocks = post.content?.length ? post.content : defaultContent;

  return (
    <>
      <div className="space-for-header" />

      <section className="tj-page-header">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="tj-page-header-content">
                <h1 className="tj-page-title">Blog Details</h1>
                <div className="tj-page-link">
                  <span>
                    <i className="tji-home"></i>
                  </span>
                  <span>
                    <Link to="/">Home</Link>
                  </span>
                  <span>
                    <i className="tji-arrow-right-4"></i>
                  </span>
                  <span>
                    <Link to="/blog">Blog</Link>
                  </span>
                  <span>
                    <i className="tji-arrow-right-4"></i>
                  </span>
                  <span>
                    <span>Blog Details</span>
                  </span>
                </div>
                <div className="shape">
                  <img src="/assets/images/shapes/stars.png" alt="" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="tj-blog-section section-gap-bottom">
        <div className="container">
          <div className="row rg-60">
            {/* ================= ARTICLE ================= */}
            <div className="col-lg-8">
              <div className="tj_wpost_wrapper">
                <div className="tj_wpost_singular">
                  <div className="tj_wpost_thumb tj-fade-anim">
                    <img src={post.image} alt={post.title} />
                  </div>

                  <h2 className="tj_wpost_title">{post.title}</h2>

 

                  {/* ---------- article content (post.content in data/BlogPosts.js) ---------- */}
                  <div className="tj_wpost_entry_content">
                    {blocks.map((block, i) => (
                      <ContentBlock key={i} block={block} />
                    ))}
                  </div>
                </div>

                {/* previous / next */}
                <div className="tj_wpost_navigation tj-fade-anim mt-5">
                  <div className="tj_prev">
                    {prev && (
                      <Link className="navigation_prev" to={blogPath(prev.slug)}>
                        <span className="navigation_icon">
                          <i className="tji-arrow-left-4"></i>
                        </span>
                        <span className="navigation_text">Previous</span>
                      </Link>
                    )}
                  </div>
                  <div className="navigation_home">
                    <Link to="/blog">
                      <i className="tji-grid"></i>
                    </Link>
                  </div>
                  <div className="tj_next">
                    {next && (
                      <Link className="navigation_next" to={blogPath(next.slug)}>
                        <span className="navigation_text">Next</span>
                        <span className="navigation_icon">
                          <i className="tji-arrow-right-4"></i>
                        </span>
                      </Link>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* ================= SIDEBAR ================= */}
            <div className="col-lg-4">
              <div className="tj_wpost_sidebar">
                <div className="tj_wpost_widget tj_widget_categories tj-fade-anim">
                  <h4 className="widget_title">Categories</h4>
                  <ul>
                    {categoryCounts().map((c) => (
                      <li key={c.key}>
                        <Link to={categoryPath(c.key)}>
                          {c.label}
                          <span className="number">({pad(c.count)})</span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="tj_wpost_widget tj_recent_posts tj-fade-anim">
                  <h4 className="widget_title">Related post</h4>
                  <ul>
                    {related.map((r) => (
                      <li key={r.slug}>
                        <div className="post-thumb">
                          <Link to={blogPath(r.slug)}>
                            <img src={r.image} alt={r.title} />
                          </Link>
                        </div>
                        <div className="post-content">
                          <h6 className="post-title">
                            <Link to={blogPath(r.slug)}>{r.title}</Link>
                          </h6>
                          <div className="post-meta">
                            <i className="tji-calendar"></i>
                            <span>{r.date}</span>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default BlogDetailsContent;